from tkinter import *


def btn_clicked():
    print("Button Clicked")


window = Tk()

window.geometry("1537x864")
window.configure(bg = "#FFFFFF")

background_img = PhotoImage(file = f"background.png")

bck_label = tk.Label(self, image=background_img,
                     relief="flat", bg="#093545")

bck_label.place(x=0, y=0, width=1537, height=864
                ,image=background_img)

img0 = PhotoImage(file = f"img0.png")

b0 = Button(self,
        image = img0,
        borderwidth = 0,
        highlightthickness = 0,
        command = b0_clicked,
        bg=  "#092f40",
        background="#092f40",
        activebackground="#092f40",
        cursor = "hand2",
        relief = "flat")

b0.place(
    x = 478, y = 639,
    width = 266,
    height = 62)

img1 = PhotoImage(file = f"img1.png")
b1 = Button(self,
        image = img1,
        borderwidth = 0,
        highlightthickness = 0,
        command = b1_clicked,
        bg=  "#092f40",
        background="#092f40",
        activebackground="#092f40",
        cursor = "hand2",
        relief = "flat")

b1.place(
    x = 827, y = 640,
    width = 266,
    height = 62)

window.resizable(False, False)
window.mainloop()
