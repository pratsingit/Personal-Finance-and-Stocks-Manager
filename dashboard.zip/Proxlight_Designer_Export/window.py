from tkinter import *


def btn_clicked():
    print("Button Clicked")


window = Tk()

window.geometry("1537x864")
window.configure(bg = "#093545")

bck_label = tk.Label(self, image=background.png,
                     relief="flat", bg="#093545")

bck_label.place(x=0, y=0, width=1537, height=864)

background_img = PhotoImage(file = f"background.png")

img0 = PhotoImage(file = f"img0.png")

b0 = Button(self,
        image = img0,
        borderwidth = 0,
        highlightthickness = 0,
        command = b0_clicked,
        bg=  "#092f40",
        background="#092f40",
        activebackground="#092f40",
        cursor = "hand2",
        relief = "flat")

b0.place(
    x = 0, y = 784,
    width = 383,
    height = 80)

img1 = PhotoImage(file = f"img1.png")
b1 = Button(self,
        image = img1,
        borderwidth = 0,
        highlightthickness = 0,
        command = b1_clicked,
        bg=  "#092f40",
        background="#092f40",
        activebackground="#092f40",
        cursor = "hand2",
        relief = "flat")

b1.place(
    x = 49, y = 344,
    width = 290,
    height = 49)

img2 = PhotoImage(file = f"img2.png")
b2 = Button(self,
        image = img2,
        borderwidth = 0,
        highlightthickness = 0,
        command = b2_clicked,
        bg=  "#092f40",
        background="#092f40",
        activebackground="#092f40",
        cursor = "hand2",
        relief = "flat")

b2.place(
    x = 49, y = 245,
    width = 290,
    height = 49)

img3 = PhotoImage(file = f"img3.png")
b3 = Button(self,
        image = img3,
        borderwidth = 0,
        highlightthickness = 0,
        command = b3_clicked,
        bg=  "#092f40",
        background="#092f40",
        activebackground="#092f40",
        cursor = "hand2",
        relief = "flat")

b3.place(
    x = 49, y = 146,
    width = 290,
    height = 49)

img4 = PhotoImage(file = f"img4.png")
b4 = Button(self,
        image = img4,
        borderwidth = 0,
        highlightthickness = 0,
        command = b4_clicked,
        bg=  "#092f40",
        background="#092f40",
        activebackground="#092f40",
        cursor = "hand2",
        relief = "flat")

b4.place(
    x = 45, y = 46,
    width = 294,
    height = 50)

window.resizable(False, False)
window.mainloop()
