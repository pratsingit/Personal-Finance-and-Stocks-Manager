from tkinter import *


def btn_clicked():
    print("Button Clicked")


window = Tk()

window.geometry("1537x864")
window.configure(bg = "#093545")

background_img = PhotoImage(file = f"background.png")
bck_label = tk.Label(self, image=background_img,
                     relief="flat", bg="#093545")
background = Label.place(x=0, y=0, width=1537, height=864 ,
                         image=background_img)

img0 = PhotoImage(file = f"img0.png")

b0 = tk.Button(self,
               image = img0,
               borderwidth = 0,
               highlightthickness = 0,
               command = btn_clicked,
               background="#092f40",
               activebackground="#092f40",
               cursor="hand2",
               relief = "flat")

b0.place(
    x = 950, y = 636,
    width = 266,
    height = 62)


img1 = PhotoImage(file = f"img1.png")

b1 = Button(
    image = img1,
    borderwidth = 0,
    highlightthickness = 0,
    command = btn_clicked,
    background="#092f40",
    activebackground="#092f40",
    cursor="hand2",
    relief = "flat")

b1.place(
    x = 644, y = 636,
    width = 266,
    height = 62)

img2 = PhotoImage(file = f"img2.png")
b2 = Button(
    image = img2,
    borderwidth = 0,
    highlightthickness = 0,
    command = btn_clicked,
    background="#092f40",
    activebackground="#092f40",
    cursor="hand2",
    relief = "flat")

b2.place(
    x = 338, y = 636,
    width = 266,
    height = 62)

window.resizable(False, False)
window.mainloop()
